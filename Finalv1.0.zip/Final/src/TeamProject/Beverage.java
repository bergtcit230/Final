package TeamProject;

public class Beverage extends Food {
}
