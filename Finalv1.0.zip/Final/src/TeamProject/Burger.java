package TeamProject;

public class Burger extends Food {



}
