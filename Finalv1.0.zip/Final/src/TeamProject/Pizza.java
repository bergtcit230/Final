package TeamProject;

public class Pizza extends Food {
}
